export class Menuitems {
  
        itemName:String;
        item_quantity:number;
        item_cost:number;
        
        constructor(
         
        itemName:String,
        item_quantity:number,
        item_cost:number,
        ){
           
            this.itemName=itemName;
            this.item_quantity=item_quantity;
            this.item_cost=item_cost;
        }
    }


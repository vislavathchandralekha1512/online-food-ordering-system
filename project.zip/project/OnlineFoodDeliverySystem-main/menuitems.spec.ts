import { Menuitems } from './menuitems';

describe('Menuitems', () => {
  it('should create an instance', () => {
    expect(new Menuitems()).toBeTruthy();
  });
});
